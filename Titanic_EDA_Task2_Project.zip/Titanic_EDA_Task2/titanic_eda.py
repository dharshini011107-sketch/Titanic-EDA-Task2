import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

DATA_FILE = Path("titanic_cleaned.csv")
OUTPUT = Path("eda_outputs")
OUTPUT.mkdir(exist_ok=True)

if not DATA_FILE.exists():
    raise FileNotFoundError(
        "titanic_cleaned.csv was not found. Put your cleaned Task 1 dataset in this folder."
    )

df = pd.read_csv(DATA_FILE)

# Basic overview
print("\n--- DATASET OVERVIEW ---")
print("Rows:", df.shape[0])
print("Columns:", df.shape[1])
print("\nColumns:")
print(list(df.columns))

print("\n--- DATA TYPES ---")
print(df.dtypes)

print("\n--- MISSING VALUES ---")
print(df.isnull().sum())

print("\n--- DESCRIPTIVE STATISTICS ---")
print(df.describe(include="all").T)

# Survival counts
if "Survived" in df.columns:
    survival_counts = df["Survived"].value_counts().sort_index()
    survival_rates = df["Survived"].value_counts(normalize=True).sort_index() * 100

    print("\n--- SURVIVAL ---")
    print(survival_counts)
    print("\nSurvival percentages:")
    print(survival_rates.round(2))

    plt.figure(figsize=(7,5))
    survival_counts.rename(index={0:"Did not survive",1:"Survived"}).plot(kind="bar")
    plt.title("Titanic Survival Distribution")
    plt.xlabel("Outcome")
    plt.ylabel("Number of Passengers")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUTPUT/"01_survival_distribution.png", dpi=200)
    plt.close()

# Gender analysis
if {"Sex","Survived"}.issubset(df.columns):
    gender_rate = df.groupby("Sex")["Survived"].mean().sort_values(ascending=False) * 100
    print("\n--- SURVIVAL RATE BY GENDER ---")
    print(gender_rate.round(2))

    plt.figure(figsize=(7,5))
    gender_rate.plot(kind="bar")
    plt.title("Survival Rate by Gender")
    plt.xlabel("Gender")
    plt.ylabel("Survival Rate (%)")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUTPUT/"02_gender_survival_rate.png", dpi=200)
    plt.close()

# Passenger class analysis
if {"Pclass","Survived"}.issubset(df.columns):
    class_rate = df.groupby("Pclass")["Survived"].mean().sort_index() * 100
    print("\n--- SURVIVAL RATE BY PASSENGER CLASS ---")
    print(class_rate.round(2))

    plt.figure(figsize=(7,5))
    class_rate.plot(kind="bar")
    plt.title("Survival Rate by Passenger Class")
    plt.xlabel("Passenger Class")
    plt.ylabel("Survival Rate (%)")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUTPUT/"03_class_survival_rate.png", dpi=200)
    plt.close()

# Age analysis
if "Age" in df.columns:
    age = pd.to_numeric(df["Age"], errors="coerce").dropna()
    print("\n--- AGE STATISTICS ---")
    print(age.describe())

    plt.figure(figsize=(8,5))
    age.plot(kind="hist", bins=20)
    plt.title("Age Distribution of Passengers")
    plt.xlabel("Age")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(OUTPUT/"04_age_distribution.png", dpi=200)
    plt.close()

# Fare analysis
if "Fare" in df.columns:
    fare = pd.to_numeric(df["Fare"], errors="coerce").dropna()
    print("\n--- FARE STATISTICS ---")
    print(fare.describe())

    plt.figure(figsize=(8,5))
    fare.plot(kind="hist", bins=20)
    plt.title("Fare Distribution")
    plt.xlabel("Fare")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(OUTPUT/"05_fare_distribution.png", dpi=200)
    plt.close()

# Family size analysis
if {"SibSp","Parch"}.issubset(df.columns):
    df["FamilySize"] = df["SibSp"].fillna(0) + df["Parch"].fillna(0) + 1
    family_rate = df.groupby("FamilySize")["Survived"].mean().sort_index() * 100 if "Survived" in df.columns else None
    print("\n--- FAMILY SIZE ---")
    print(df["FamilySize"].describe())

    if family_rate is not None:
        print("\nSurvival rate by family size:")
        print(family_rate.round(2))

# Automatically write insight statements from the actual results
insights = []

if {"Sex","Survived"}.issubset(df.columns):
    g = df.groupby("Sex")["Survived"].mean() * 100
    if len(g) >= 2:
        high = g.idxmax()
        low = g.idxmin()
        insights.append(
            f"1. {high.capitalize()} passengers had the higher survival rate "
            f"({g[high]:.1f}%) compared with {low} passengers ({g[low]:.1f}%)."
        )

if {"Pclass","Survived"}.issubset(df.columns):
    c = df.groupby("Pclass")["Survived"].mean() * 100
    high = c.idxmax()
    low = c.idxmin()
    insights.append(
        f"2. Passenger class showed a clear difference in survival: "
        f"Class {high} had the highest rate ({c[high]:.1f}%), while Class {low} had the lowest ({c[low]:.1f}%)."
    )

if "Age" in df.columns:
    age = pd.to_numeric(df["Age"], errors="coerce").dropna()
    if len(age):
        insights.append(
            f"3. The average passenger age was {age.mean():.1f} years, "
            f"with ages ranging from {age.min():.1f} to {age.max():.1f} years."
        )

if "Fare" in df.columns:
    fare = pd.to_numeric(df["Fare"], errors="coerce").dropna()
    if len(fare):
        insights.append(
            f"4. The average fare was {fare.mean():.2f}, while the maximum recorded fare was {fare.max():.2f}, "
            f"showing a wide spread in ticket prices."
        )

if {"SibSp","Parch","Survived"}.issubset(df.columns):
    temp = df.copy()
    temp["FamilySize"] = temp["SibSp"].fillna(0) + temp["Parch"].fillna(0) + 1
    fs = temp.groupby("FamilySize")["Survived"].mean() * 100
    if len(fs):
        best = fs.idxmax()
        insights.append(
            f"5. Family size also varied in survival rate; the highest observed rate was for "
            f"family size {best} ({fs[best]:.1f}%)."
        )

if "Survived" in df.columns:
    total_survival = df["Survived"].mean() * 100
    insights.append(
        f"6. Overall, {total_survival:.1f}% of passengers in the cleaned dataset survived."
    )

print("\n--- FIVE+ USEFUL INSIGHTS ---")
for item in insights:
    print(item)

with open(OUTPUT/"insights.txt", "w", encoding="utf-8") as f:
    f.write("Titanic EDA – Key Insights\n\n")
    for item in insights:
        f.write(item + "\n")
