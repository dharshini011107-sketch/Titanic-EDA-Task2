# Task 2 – Exploratory Data Analysis of Titanic Dataset

## Objective
Perform exploratory data analysis on the cleaned Titanic dataset from Task 1 and identify useful trends, patterns and anomalies.

## Tools
- Python
- Pandas
- Matplotlib
- Jupyter Notebook

## Files
- `Titanic_EDA.ipynb` – complete EDA notebook
- `titanic_eda.py` – Python script version
- `README.md` – project documentation
- `requirements.txt` – required Python packages

## Dataset
Place the cleaned dataset from Task 1 in this folder and name it:

`titanic_cleaned.csv`

The notebook/script automatically reads this file.

## Analysis Included
1. Dataset overview and data types
2. Missing-value check
3. Descriptive statistics
4. Survival distribution
5. Gender-wise survival analysis
6. Passenger-class survival analysis
7. Age distribution
8. Fare distribution
9. Family-size analysis
10. At least five useful insights generated from the actual dataset

## Expected Charts
- Survival Count
- Survival Rate by Gender
- Survival Rate by Passenger Class
- Age Distribution
- Fare Distribution

## Key Insight Format
The final section explains at least five observations using the calculated results rather than assumptions.

## Submission
Upload this project folder to the same GitHub repository used for Task 1 after adding `titanic_cleaned.csv`.

Then use the GitHub repository URL as the Task Submission Link.

For the LinkedIn Video Explanation Post Link, paste the URL of the LinkedIn post containing the screen-recorded explanation.
